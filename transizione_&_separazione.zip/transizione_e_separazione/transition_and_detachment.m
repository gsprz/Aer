% transition and separation analysis

clear all
close all
clc


airfoils = {'b737d','naca0012'}; % string
version = 14; % integer
N = 364; % integer: # of panels
tgap = [0 .04]; % float vector: [gap, blend_dist]
iter_lim = 100;

alfa_vec = 10; % [2];
Re_vec = 2.5e6; % (.5:.5:4).*1e6; 
Ncrit_vec = 12; % [5,9,12];



for af = 1:length(airfoils)
    airfoil = airfoils{af};
    for i = 1:length(Re_vec)
    
        Re = Re_vec(i);
        Ma = 0;
    
        for j = 1:length(Ncrit_vec)
            Ncrit = Ncrit_vec(j);
    
            for k = 1:length(alfa_vec)
    
                alpha = alfa_vec(k);
                
                xfoil_input(airfoil, version, N, tgap, alpha, [], Re, Ma, Ncrit, iter_lim, []);  

                % transition point    
                filename = sprintf('%s_v%d_VISCpolars.dat', airfoil, version);
                fid = fopen(filename, 'r');
                while ~feof(fid) % skip lines until data table starts
                    line = fgetl(fid);
                    if contains(line, 'alpha    CL') % find the header of the data table
                        break;
                    end
                end
                data = [];
                while ~feof(fid)
                    line = fgetl(fid); % read the line
                    if isempty(line) || ~ischar(line) % stop if the line is empty
                        break;
                    end
                    values = sscanf(line, '%f'); % get the data
                    if length(values) >= 2        % check that the line has at least `alpha` and `CL`
                        data = [data; values'];   
                    end
                end
                fclose(fid);
                if ~isempty(data)
                    % alfaXtr(i,j,k) = data(:,1); 
                    topXtr{i,j,k,af} = data(:, 6); % Top_Xtr column
                    botXtr{i,j,k,af} = data(:, 6); % Bot_Xtr column
                else
                    % alfaXtr(i,j,k) = NaN; 
                    topXtr{i,j,k,af} = NaN; 
                    botXtr{i,j,k,af} = NaN; 
                end
                
                % detachment
                filename = sprintf('%s_v%d_a%.2f_dumps.dat', airfoil, version, alpha);
                fid = fopen(filename, 'r');
                if fid == -1
                    error('File not opened: %s', filename);
                end
                data = [];
                while ~feof(fid)
                    line = fgetl(fid); % read the row
                    if isempty(line) || ~ischar(line) % skip empty/non-valid lines
                        continue;
                    end
                    values = sscanf(line, '%f'); % find numerical values
                    if length(values) >= 12 % # of cols from xfoil formatting
                        data = [data; values']; 
                    end
                end
                fclose(fid);
                if isempty(data)
                    warning('No data in file: %s', filename);
                    % topCFsep{i,j,k,af} = NaN; 
                    % botCFsep{i,j,k,af} = NaN; 
                    continue;
                else
                    CF_xfoil = data(:, 7); % from xfoil formatting, Cf is @ 7th column   
                    xx = data(:,2); % store x-points
                    yy = data(:,3);
                    UeVinf = data(:,4);
                    inversion_index = find(UeVinf <= 0, 1, 'first');
                    xd = flip(xx(1:inversion_index)); % top side
                    xv = xx(inversion_index+1:end); % bottom side
                    CF_aux = CF_xfoil(1:length(data(:,11))); % take only the body-panels-referred CFs
                    CFd = flip(CF_aux(1:inversion_index));
                    CFv = CF_aux(inversion_index+1:end);

                    topCFsep{i,j,k,af} = CFd;
                    botCFsep{i,j,k,af} = CFv;
                   
    
                end
                
            end
        end
    end
    xx_af(:,af) = xx;
    yy_af(:,af) = yy;
end

%% detachment plot

i = length(Re_vec); 
j = length(Ncrit_vec); 
k = length(alfa_vec);

figure
max_CF = 0;
min_CF = 0;
for af = 1:length(airfoils)
    subplot(2,1,af)

    xx = xx_af(:,af);
    yy = yy_af(:,af);

    CF = [flip(topCFsep{i,j,k,af}); botCFsep{i,j,k,af}];
    if min(CF) < min_CF
        min_CF = min(CF);
    end
    if max(CF) > max_CF
        max_CF = max(CF);
    end
    scatter(xx, yy, 200, CF, 'o','filled', 'HandleVisibility', 'off'); 
    hold on
    colormap("parula"); 
    c = colorbar;  
    c.FontSize = 24
    % ylabel(c,'Coefficiente di attrito a parete')
    caxis([-0.005 0.05]);
    xlabel('x/c');
    ylabel('y/c');
    title(sprintf('Distribuzione del CF ', airfoils{af}, alfa_vec(k), Re_vec(i), Ncrit_vec(j)));

    grid on;
    axis equal
        grid on
        set(gcf, 'Color', 'w');
        ax = gca;
        %ax.LineWidth = 0.8;
        ax.XAxis.FontSize = 24;  
        ax.YAxis.FontSize = 24; 
        %ax.Legend.FontSize = 18;
        ax.Title.FontSize = 24;
end



%% transition plot

ii = 1:length(Re_vec);
jj = 1:length(Ncrit_vec);
kk = 1:length(alfa_vec);
aa = 1:length(airfoils);

figure
set(gcf, 'Renderer', 'painters');
for af = aa
    for k = kk
        hold on

        for j = jj
            x_data = Re_vec(ii);
            y_data = [];
            for idx = ii
                y_data = [y_data; topXtr{idx, j, k, af}];
            end
            
            % NaN intervals
            isnan_mask = isnan(y_data);
            
            if af == 1
                if j == 1
                    plot(x_data(~isnan_mask), y_data(~isnan_mask), '-o', ...
                         'DisplayName', sprintf('%s [Ncrit = %d]', airfoils{af}, Ncrit_vec(j)), 'LineWidth',3, 'Color', [0.7/2, 0.85/2, 0.9])
                    hold on
                elseif j == 2
                    plot(x_data(~isnan_mask), y_data(~isnan_mask), '-.o', ...
                         'DisplayName', sprintf('%s [Ncrit = %d]', airfoils{af}, Ncrit_vec(j)), 'LineWidth',3, 'Color', [0.7/2, 0.85/2, 0.9])
                    hold on
                elseif j == 3
                    plot(x_data(~isnan_mask), y_data(~isnan_mask), '--o', ...
                         'DisplayName', sprintf('%s [Ncrit = %d]', airfoils{af}, Ncrit_vec(j)), 'LineWidth',3, 'Color', [0.7/2, 0.85/2, 0.9])
                    hold on
                end
            else
                if j == 1
                    plot(x_data(~isnan_mask), y_data(~isnan_mask), '-o', ...
                         'DisplayName', sprintf('%s [Ncrit = %d]', airfoils{af}, Ncrit_vec(j)), 'LineWidth',3, 'Color', [0.98, 0.85/2, 0.65/2])
                    hold on
                elseif j == 2
                    plot(x_data(~isnan_mask), y_data(~isnan_mask), '-.o', ...
                         'DisplayName', sprintf('%s [Ncrit = %d]', airfoils{af}, Ncrit_vec(j)), 'LineWidth',3, 'Color', [0.98, 0.85/2, 0.65/2])
                    hold on
                elseif j == 3
                    plot(x_data(~isnan_mask), y_data(~isnan_mask), '--o', ...
                         'DisplayName', sprintf('%s [Ncrit = %d]', airfoils{af}, Ncrit_vec(j)), 'LineWidth',3, 'Color', [0.98, 0.85/2, 0.65/2])
                    hold on
                end
            end
            
            % add interpolation for non-convergent cases
            nan_indices = find(isnan_mask);
            for idx = 1:length(nan_indices)
                if nan_indices(idx) > 1 && nan_indices(idx) < length(y_data)

                    prev_idx = nan_indices(idx) - 1; 
                    next_idx = nan_indices(idx) + 1; 
                    
                    if ~isnan(y_data(prev_idx)) && ~isnan(y_data(next_idx))
                        plot((x_data(prev_idx)+x_data(next_idx))/2, (y_data(prev_idx)+y_data(next_idx))/2, 'ok', 'LineWidth', 3, 'HandleVisibility', 'off')
                    end
                end
            end
        end

        if af == aa(end)
            plot(nan, nan, 'ok', 'LineWidth', 3,'DisplayName', 'Punti non convergenti');
        end
        
        legend show
        xlabel('Re')
        ylabel('x/c')
        ylim([0 1])
        title(sprintf('Punto di transizione lungo il dorso [\alpha = %.1f° - Re, Ncrit variabili]', alfa_vec(k)))
        xlim([0.5 4]*1e6)
        grid on
        set(gcf, 'Color', 'w');
        ax = gca;
        %ax.LineWidth = 0.8;
        ax.XAxis.FontSize = 24;  
        ax.YAxis.FontSize = 24; 
        ax.Legend.FontSize = 24;
        ax.Title.FontSize = 24;
        
    end
end
% print('-dpng', 'figure.png', '-vector', '-r300')  
% set(gcf, 'Renderer', 'opengl');
% exportgraphics(ax,"nome.png","Resolution",300) 




























