%% traccia Hess Smith (2024)

clc
close all
clear 

 addpath mat_functions

%% Input

U_inf = 1;  % Velocità all'infinito [m/s]
alpha = 2;   % Angolo di incidenza [°]
U_inf_x = U_inf * cos(deg2rad(alpha));
U_inf_y = U_inf * sin(deg2rad(alpha));

U_inf = [U_inf_x; U_inf_y];
U_inf_normal = [-U_inf(2); U_inf(1)];
U_inf_normal = U_inf_normal ./ norm(U_inf_normal);

TestCase = 0;

CodiceProfilo = '';
Chord = 1;
NPannelli = 363;

LE_X_Position = 0;
LE_Y_Position = 0;

%% Creazione profilo

% numero profilo:
% [x,y]=createProfile(CodiceProfilo,NPannelli,Chord);

riferimento = 1;
% con riferimento = 1 si analizza il naca0012, con riferimento uguale a
% qualsiasi altro numero si analizza il B737D

if riferimento == 1
    Corpo = importXfoilProfile(strcat('naca0012v8', CodiceProfilo, '.dat'));
else
    Corpo = importXfoilProfile(strcat('b737d_smooth', CodiceProfilo, '.dat'));
end
% Prima flippa i vettori
x = flipud(Corpo.x);
y = flipud(Corpo.y);
Corpo.x = x.*Chord;
Corpo.y = y.*Chord;


%% Creazione di una struttura di pannelli

[Centro, Normale, Tangente, Estremo_1, Estremo_2, alpha, lunghezza, L2G_TransfMatrix, G2L_TransfMatrix] = CreaStrutturaPannelli(Corpo);
        
%% Inizializzazione matrici e vettori

% Ora che ho i pannelli, posso inizializzare la matrice ed i vettori

NCols = sum(NPannelli) + 1;
NRows = NCols;
matriceA = zeros(NRows, NCols);
TermineNoto = zeros(NRows, 1);

%% Creazione della matrice quadrata As


for i = 1:NPannelli
    index_i = i; % riga

    Centro_qui = Centro(i, :)';
    Normale_qui = Normale(i, :)';

    indexStart_colonna = 0;

        for j = 1:NPannelli
            index_j = indexStart_colonna + j;  % Colonna

            Estremo_1_qui = Estremo_1(j, :)';
            Estremo_2_qui = Estremo_2(j, :)';

            L2G_TransfMatrix_qui = squeeze(L2G_TransfMatrix(j, :, :));
            G2L_TransfMatrix_qui = squeeze(G2L_TransfMatrix(j, :, :));

            matriceA(index_i, index_j) = dot(ViSorgente(Centro_qui, Estremo_1_qui, Estremo_2_qui, L2G_TransfMatrix_qui, G2L_TransfMatrix_qui), Normale_qui);

            matriceA(index_i, sum(NPannelli)+1) = matriceA(index_i, sum(NPannelli)+1) + dot(ViVortice(Centro_qui, Estremo_1_qui, Estremo_2_qui, L2G_TransfMatrix_qui, G2L_TransfMatrix_qui), Normale_qui);


        end

end


%% Creazione delle componenti dei vettori a_v, c_s e c_v


Centro_Start = Centro(1, :)';
Tangente_Start = Tangente(1, :)';

Centro_End = Centro(end, :)';
Tangente_End = Tangente(end, :)';


b = 0;
for j = 1:NPannelli(1)

    index_j = j;

    Estremo_1_qui = Estremo_1(j, :)';
    Estremo_2_qui = Estremo_2(j, :)';
    L2G_TransfMatrix_qui = squeeze(L2G_TransfMatrix(j, :, :));
    G2L_TransfMatrix_qui = squeeze(G2L_TransfMatrix(j, :, :));

    a = dot(ViSorgente(Centro_Start, Estremo_1_qui, Estremo_2_qui, L2G_TransfMatrix_qui, G2L_TransfMatrix_qui), Tangente_Start);
    b = b + dot(ViVortice(Centro_Start, Estremo_1_qui, Estremo_2_qui, L2G_TransfMatrix_qui, G2L_TransfMatrix_qui), Tangente_Start);

    a = a + dot(ViSorgente(Centro_End, Estremo_1_qui, Estremo_2_qui, L2G_TransfMatrix_qui, G2L_TransfMatrix_qui), Tangente_End);
    b = b + dot(ViVortice(Centro_End, Estremo_1_qui, Estremo_2_qui, L2G_TransfMatrix_qui, G2L_TransfMatrix_qui), Tangente_End);


    matriceA(sum(NPannelli) + 1, index_j) = a;

end

matriceA(sum(NPannelli) + 1, sum(NPannelli) + 1) = b;



%% Creazione del termine noto

for j = 1:NPannelli

    Normale_qui = Normale(j, :)';

    index = j;

    TermineNoto(index) = - dot(U_inf, Normale_qui);
end

Tangente_1 = Tangente(1, :)';
Tangente_end = Tangente(end, :)';
TermineNoto(sum(NPannelli) + 1) = - dot(U_inf, (Tangente_1 + Tangente_end));

%% Risoluzione sistema lineare
Soluzione = linsolve(matriceA,TermineNoto);

%% Compute velocity on control points and pressure distribution
velu= zeros(NPannelli,1); 
velv = velu;
% xe= Estremo_1(:,1);
% ye= Estremo_1(:,2);
xp= Centro(:,1);
yp= Centro (:,2);
sigma=Soluzione(1:length(Soluzione)-1);
gamma=Soluzione(end);

for i=1:NPannelli
    velu(i) = U_inf(1); 
    velv(i) = U_inf(2);
    for j=1:NPannelli
        [sou.u,sou.v] = source(Estremo_1(j,1),Estremo_1(j,2),Estremo_2(j,1),Estremo_2(j,2),xp(i),yp(i));
        [vor.u,vor.v] = vortex(Estremo_1(j,1),Estremo_1(j,2),Estremo_2(j,1),Estremo_2(j,2),xp(i),yp(i));
       velu(i) = velu(i) + sigma(j)*sou.u + gamma*vor.u;
       velv(i) = velv(i) + sigma(j)*sou.v + gamma*vor.v;
    end

end

length = sqrt((Estremo_2(:,1)-(Estremo_1(:,1))).^2+(Estremo_2(:,2)-Estremo_1(:,2)).^2);
Vt = velu.*Tangente(:,1) + velv.*Tangente(:,2);
Cp = 1-Vt.^2/(U_inf(1)^2+U_inf(2)^2);
Cl = -Cp'*( length.*Normale(:,2) )

rp = zeros(NPannelli,3);
rp(:,1) = xp;
rp(:,2) = yp;

normal = zeros(NPannelli, 3);
normal(:,1) = Normale(:,1);
normal(:,2) = Normale(:,2);

Cm_le_dot = zeros(NPannelli,1);
Cm_le_dot(1,1) = 0;
for i = 1:NPannelli
    Cm_le_dot(i,1) = dot(cross(rp(i,:), normal(i,:)), [0 0 1]);
end
Cm_le = Cp'*(length .* Cm_le_dot);
Cm_ac = Cm_le +  Cl * 1/4

if riferimento == 1
    tab = readtable('naca0012v8_cpx2.dat'); % xfoil output file naca0012x_vs_cp
    xvscp = table2array(tab);
else
    tab = readtable('b737d_refined_cp.dat');
    xvscp = table2array(tab);
end

[min_xv, flag_min_xv] = min(xvscp(:,1));
[min_xp, flag_min_xp] = min(xp);
Cp_lower_xfoil = xvscp(1:flag_min_xv,:);
Cp_upper_xfoil = xvscp(flag_min_xv:end,:);

Cp_upper = Cp(1:flag_min_xp);
Cp_lower = Cp(flag_min_xp:end);

xx = linspace(0,1,100);
xp_spline_lower = xp(flag_min_xp:end);
xp_spline_upper = xp(1:flag_min_xp);

Cp_lower_xfoil_spline = spline(Cp_lower_xfoil(:,1), Cp_lower_xfoil(:,2), xx);
Cp_upper_xfoil_spline = spline(Cp_upper_xfoil(:,1), Cp_upper_xfoil(:,2), xx);
Cp_upper_spline = spline(xp_spline_upper, Cp_upper, xx);
Cp_lower_spline = spline(xp_spline_lower, Cp_lower, xx);


%%
figure
plot(xx, Cp_lower_spline, '-o')
hold on
plot(xx, Cp_upper_spline, '-o')
plot(xx, Cp_upper_xfoil_spline, LineWidth=1.5)
plot(xx, Cp_lower_xfoil_spline, LineWidth=1.5)
grid on
xlabel('x/c')
ylabel('Cp')
legend('Cp ventre xfoil', 'Cp dorso xfoil', 'Cp dorso Hess Smith', 'Cp ventre Hess Smith', 'FontSize', 10)
grid on
set(gca, 'YDir', 'reverse')

%% Source and vortex functions
function [u,v] = source( xe1, ye1, xe2, ye2, x, y)
l=sqrt((xe2-xe1)^2+(ye2-ye1)^2); %lunghezza del pannello
% coordinate nel riferimento locale
xl2 = l; yl2=0;
xl=(x-xe1)*(xe2-xe1)/l+(y-ye1)*(ye2-ye1)/l; yl=-(x-xe1)*(ye2-ye1)/l+(y-ye1)*(xe2-xe1)/l; % posizione del punto (x,y) nel riferimento locale
r1=sqrt(xl^2+yl^2); r2=sqrt((xl-xl2)^2+(yl-yl2)^2); %calcolo r1 e r2
theta1=atan2(yl,xl); theta2=atan2(yl-yl2,xl-xl2); % calcolo theta1 e theta2

if (abs(theta1)<10^(-12) && abs(theta2)>3); theta1=0; theta2=pi; end % controllo per evitare errori numerici
if (abs(theta2)<10^(-12) && abs(theta1)>3); theta2=0; theta1=-pi; end % controllo per evitare errori numerici
% velocità indotta nel riferimento locale
vl=1/(2*pi)*(theta2-theta1); 
ul=1/(2*pi)*log(r1/r2);
% velocità indotta nel riferimento globale
u=ul*(xe2-xe1)/l-vl*(ye2-ye1)/l; 
v=ul*(ye2-ye1)/l+vl*(xe2-xe1)/l;
end

function [u,v] = vortex( xe1, ye1, xe2, ye2, x, y)
l=sqrt((xe2-xe1)^2+(ye2-ye1)^2);
xl2 = l; yl2=0;
xl=(x-xe1)*(xe2-xe1)/l+(y-ye1)*(ye2-ye1)/l; yl=-(x-xe1)*(ye2-ye1)/l+(y-ye1)*(xe2-xe1)/l;
r1=sqrt(xl^2+yl^2); r2=sqrt((xl-xl2)^2+(yl-yl2)^2);
theta1=atan2(yl,xl); theta2=atan2(yl-yl2,xl-xl2);
if (abs(theta1)<10^(-12) && abs(theta2)>3); theta1=0; theta2=pi; end
if (abs(theta2)<10^(-12) && abs(theta1)>3); theta2=0; theta1=-pi; end
% velocità indotta nel riferimento locale
ul=1/(2*pi)*(theta2-theta1); 
vl=-1/(2*pi)*log(r1/r2);
% velocità indotta nel riferimento globale
u=ul*(xe2-xe1)/l-vl*(ye2-ye1)/l;
v=ul*(ye2-ye1)/l+vl*(xe2-xe1)/l;
end

