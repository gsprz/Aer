function xfoil_input(airfoil, version, N, tgap, alpha, aseq, Re, Ma, Ncrit, iter_lim, specCL)
    
    % inputs check
    if ~exist('aseq', 'var') || isempty(aseq)
        aseq = zeros(3, 1);
    end
    if ~exist('Re', 'var') || isempty(Re)
        Re = 0;
    end
    if ~exist('Ma', 'var') || isempty(Ma)
        Ma = 0;
    end
    if ~exist('Ncrit', 'var') || isempty(Ncrit) % add
        Ncrit = 9;
    end
    if ~exist('iter_lim', 'var') || isempty(iter_lim)
        iter_lim = 0;
    end
    if ~exist('specCL', 'var') || isempty(specCL)
        specCL = NaN;
    end
    %

    % following lines create/overwrite an xfoil input file
    filename = sprintf('%s_v%d_inputs.dat', airfoil, version);
    fileID = fopen(filename, 'w');
    if fileID == -1
        error('Could not open file for writing.');
    end
    fprintf(fileID, 'load %s.dat\n\n', airfoil);
    fprintf(fileID, 'pane\n\n');
    fprintf(fileID, 'gdes\n');
    fprintf(fileID, 'tgap %f %f\n', tgap(1), tgap(2));
    fprintf(fileID, 'exec\n\n');
    fprintf(fileID, 'ppar\n');
    fprintf(fileID, 'n  %d\n \n\n', N); % add \n\n

    % add filter to smooth surface and Cp
    fprintf(fileID, 'mdes\n');
    fprintf(fileID, 'filt\n');
    fprintf(fileID, 'exec\n\n'); 
    fprintf(fileID, 'pane\n');
    fprintf(fileID, 'save %s_v%d.dat\ny\n\n', airfoil, version);
    fprintf(fileID, 'oper\n');
    fprintf(fileID, 'alfa %f\n', alpha);
    fprintf(fileID, 'cpwr\n');
    fprintf(fileID, '%s_v%d_cpx.dat\ny\n\n', airfoil, version);

    % specCl mode
    if ~isnan(specCL)
        fprintf(fileID, 'oper\n');
        fprintf(fileID, 'pacc\n\n\n');
        fprintf(fileID, 'cl %.f\n', specCL);
        fprintf(fileID, 'pacc\n');
        fprintf(fileID, 'pwrt\n');
        fprintf(fileID, '%s_v%d_alfaZL.dat\ny\n', airfoil, version);
        fprintf(fileID, 'pdel\n0\n\n');
    end
    % polars characterisation
    if norm(aseq) ~= 0
        fprintf(fileID, 'oper\n');
        fprintf(fileID, 'pacc\n\n\n');
        fprintf(fileID, 'aseq %f %f %f\n', aseq(1), aseq(2), aseq(3));
        fprintf(fileID, 'pacc\n');
        fprintf(fileID, 'pwrt\n');
        fprintf(fileID, '%s_v%d_polars.dat\ny\n', airfoil, version); %
        fprintf(fileID, 'pdel\n0\n\n'); %
    else % add
        fprintf(fileID, 'oper\n');
        fprintf(fileID, 'pacc\n\n\n');
        fprintf(fileID, 'alfa %f\n', alpha);
        fprintf(fileID, 'pacc\n');
        fprintf(fileID, 'pwrt\n');
        fprintf(fileID, '%s_v%d_polars.dat\ny\n', airfoil, version); %
        fprintf(fileID, 'pdel\n0\n\n'); %
    end
    % viscous mode, if requested
    if Re > 0 
        if norm(aseq) ~= 0
            av = aseq(1):aseq(3):aseq(2);
            for i = 1:length(av)
                fprintf(fileID, 'oper\n');
                    % to help with convergence:
                    fprintf(fileID, 'alfa 0\n');
                fprintf(fileID, 'visc\n');
                fprintf(fileID, '%f\n', Re);
                fprintf(fileID, 'mach %f\n', Ma);
                fprintf(fileID, 'iter %d\n', iter_lim);
                if Ncrit ~= 9 
                    fprintf(fileID, 'vpar\n');
                    fprintf(fileID, 'N %d\n\n', Ncrit);
                end

                % to help with convergence:
                if av(i) >= 0
                    conv_aid = round(linspace(0,av(i),5),2); 
                else
                    conv_aid = round(linspace(av(i),0,5),2); % ++
                end
                for alfa_aid = conv_aid(1:end-1) % ++
                    fprintf(fileID, 'alfa %f\n', alfa_aid);
                end

                % to record Xtr:
                fprintf(fileID, 'pacc\n\n\n');
                fprintf(fileID, 'alfa %f\n', av(i));
                fprintf(fileID, 'dump\n'); % ++
                fprintf(fileID, '%s_v%d_a%.2f_dumps.dat\ny\n', airfoil, version, av(i)); % ++
                fprintf(fileID, 'pacc\n');
                fprintf(fileID, 'pwrt\n');
                fprintf(fileID, '%s_v%d_VISCpolars.dat\ny\n', airfoil, version);
                fprintf(fileID, 'pdel\n0\n');

                % to monitor the CF versus x/c
                fprintf(fileID, 'vplo\n'); %
                fprintf(fileID, 'cf\n\n'); %

                fprintf(fileID, 'visc\n\n');
            end
        else
            fprintf(fileID, 'oper\n');
                    % to help with convergence:
                    fprintf(fileID, 'alfa 0\n');
            fprintf(fileID, 'visc\n');
            fprintf(fileID, '%f\n', Re);
            fprintf(fileID, 'mach %f\n', Ma);
            fprintf(fileID, 'iter %d\n', iter_lim);
            if Ncrit ~= 9
                fprintf(fileID, 'vpar\n');
                fprintf(fileID, 'N %d\n\n', Ncrit);
            end

            % to help with convergence:
            if alpha >= 0
                conv_aid = round(linspace(0,alpha,8),2);
            else
                conv_aid = round(linspace(alpha,0,5),2); % ++
            end
            for alfa_aid = conv_aid(1:end-1) % ++
                fprintf(fileID, 'alfa %f\n', alfa_aid);
            end

            % to record Xtr:
            fprintf(fileID, 'pacc\n\n\n');
            fprintf(fileID, 'alfa %f\n', alpha);
            fprintf(fileID, 'dump\n'); % ++
            fprintf(fileID, '%s_v%d_a%.2f_dumps.dat\ny\n', airfoil, version, alpha); % ++
            fprintf(fileID, 'pacc\n');
            fprintf(fileID, 'pwrt\n');
            fprintf(fileID, '%s_v%d_VISCpolars.dat\ny\n', airfoil, version);
            fprintf(fileID, 'pdel\n0\n');


            % to monitor the CF versus x/c
            fprintf(fileID, 'vplo\n'); %
            fprintf(fileID, 'cf\n\n'); %

            fprintf(fileID, 'visc\n\n');
        end
    end
    % fprintf(fileID, 'init\n'); % mod **
    fprintf(fileID, 'quit\n');
    fclose(fileID);


    fprintf('Files created successfully.\n');

    % following lines execute xfoil analisys
    command = sprintf('xfoil < %s_v%d_inputs.dat', airfoil, version);
    status = system(command);
    if status == 0
        disp('XFOIL launched successfully.');
    else
        disp('Error launching XFOIL.');
    end
    %



end

