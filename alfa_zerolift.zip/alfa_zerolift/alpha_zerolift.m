% zero lift angle
clear all
close all
clc

clean = 1;

airfoil = 'b737d'; % string
version = 1; % integer
N = 364; % integer: # of panels
tgap = [0 .04]; % float vector: [gap, blend_dist]
alpha  = 2; % float: angle of attack


specCl = 0; % to find alfa @ zero lift
xfoil_input(airfoil, version, N, tgap, alpha, [], [], [], [], [], specCl);  

% AoA at which the lift is zero  
filename = sprintf('%s_v%d_alfaZL.dat', airfoil, version);
fid = fopen(filename, 'r');
while ~feof(fid) % skip lines until data table starts
    line = fgetl(fid);
    if contains(line, 'alpha') % find the header of the data table
        break;
    end
end
data = [];
while ~feof(fid)
    line = fgetl(fid); % read the line
    if isempty(line) || ~ischar(line) % stop if the line is empty
        break;
    end
    value = sscanf(line, '%f'); % get the data  

end
fclose(fid);
alfaZL = value(1);
