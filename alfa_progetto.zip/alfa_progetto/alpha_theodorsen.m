% Theodorsen's angle
clear all
close all
clc

clean = 1;

airfoil = 'b737d'; % string
version = 1; % integer
N = 364; % integer: # of panels
tgap = [0 .04]; % float vector: [gap, blend_dist]

figure
hold on

step = .001;
a_vec = 1:step:2; % alpha_start
    [alpha_TH, x_vec, dCp_vec] = alphaTH(a_vec, airfoil, version, N, tgap);
    plot(a_vec, dCp_vec, '-*')

alpha_TH


function [aTH, x_vec, dCp_vec]  = alphaTH(a_vec, airfoil, version, N, tgap)
    dCp_vec = ones(size(a_vec));
    i = 1;
    Cp_mat = [];
    for i = 1:length(a_vec)
    
        aa = a_vec(i);
    
        filename = sprintf('%s_v%d_inputs.dat', airfoil, version);
        fileID = fopen(filename, 'w');
        fprintf(fileID, 'load %s.dat\n\n', airfoil);
        fprintf(fileID, 'pane\n\n');
        fprintf(fileID, 'gdes\n');
        fprintf(fileID, 'tgap %f %f\n', tgap(1), tgap(2));
        fprintf(fileID, 'exec\n\n');
        fprintf(fileID, 'pane\n');
        fprintf(fileID, 'ppar\n');
        fprintf(fileID, 'n  %d\n', N);
        fprintf(fileID, '\n\n');
        fprintf(fileID, 'pane\n');
        fprintf(fileID, 'mdes\n');
        fprintf(fileID, 'filt\n');
        fprintf(fileID, 'exec\n\n');
        fprintf(fileID, 'pane\n');
        fprintf(fileID, 'save %s_v%d.dat\ny\n\n', airfoil, version);
        fprintf(fileID, 'oper\n');
        fprintf(fileID, 'alfa %f\n', aa);
        fprintf(fileID, 'cpwr\n');
        fprintf(fileID, '%s_v%d_a%.2f_cpx.dat\ny\n\n', airfoil, version, aa);
        fprintf(fileID, 'quit\n');
        fclose(fileID);
        % xfoil execution
        command = sprintf('xfoil < %s_v%d_inputs.dat', airfoil, version);
        status = system(command);
        % results loading
        filename = sprintf('%s_v%d_a%.2f_cpx.dat', airfoil, version, aa);
        tab = readtable(filename); % read xfoil output file 
        xvscp = table2array(tab);
        x_vec = xvscp(:,1);
        Cp_vec = xvscp(:,2);
        Cp_mat = [Cp_mat, Cp_vec];
        % results analysis
        diff_sign = diff(sign(diff(x_vec)));
        inversion_index = find(diff_sign ~= 0, 1, 'first') + 1;
        dCp_at0 = abs(Cp_vec(inversion_index+1) - Cp_vec(inversion_index+2));
        dCp_vec(i) = dCp_at0;
    
        % clean temporary files
        clc
        pattern = sprintf('*_v%d_*_cpx.dat',version);
        files = dir(pattern);
        for k = 1:length(files)
            delete(files(k).name);
        end
    end
    %
    [min_dCp, min_dCp_idx] = min(dCp_vec);

    aTH = a_vec(min_dCp_idx);

end