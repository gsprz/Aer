function [v_par,v_wake] = induced_velocity(gamma, ControlPoint, Extreme_1, Extreme_2)

r0 = Extreme_2 - Extreme_1;
r1 = ControlPoint - Extreme_1;
r2 = ControlPoint - Extreme_2;
r1_norm = r1 / norm(r1);
r2_norm = r2 / norm(r2);

v_por = gamma/(4*pi)*dot(r0, r1_norm - r2_norm).*cross(r1,r2)/((norm(cross(r1,r2)))^2);

% velocity for left wake

v_wake_l = gamma/(4*pi)*1/((r1(3))^2+(-r1(2))^2)*(1+(r1(1))/(norm(r1)))*...
            [0;r1(3);-r1(2)];

% velocity for right wake

v_wake_r = -gamma/(4*pi)*1/((r2(3))^2+(-r2(2))^2)*(1+(r2(1))/(norm(r2)))*...
            [0;r2(3);-r2(2)];

v_wake = v_por + v_wake_l + v_wake_r;
v_par = v_wake_l + v_wake_r;

end