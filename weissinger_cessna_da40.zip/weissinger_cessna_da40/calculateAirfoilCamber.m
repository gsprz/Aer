
function camber = calculateAirfoilCamber(X_upper, Y_upper, X_lower, Y_lower)
    % Function to calculate the camber line of an airfoil
    % Inputs:
    %   X_upper, Y_upper: X and Y coordinates of the upper surface
    %   X_lower, Y_lower: X and Y coordinates of the lower surface
    % Output:
    %   camber: A matrix with two columns. 
    %           The first column is the X-coordinate of the camber line.
    %           The second column is the Y-coordinate of the camber line.

    % Ensure the surfaces have the same X-coordinates (if not, interpolate)
    if ~isequal(X_upper, X_lower)
        error('Upper and lower surfaces must have matching X-coordinates.');
    end
    
    % Calculate the camber line as the midpoint between the upper and lower surfaces
    camberX = X_upper;  % X-coordinates of camber line (same as X_upper or X_lower)
    camberY = (Y_upper + Y_lower) / 2;  % Y-coordinates of camber line (average of upper and lower)
    
    % Combine the X and Y coordinates into a single matrix
    camber = [camberX', camberY'];
end