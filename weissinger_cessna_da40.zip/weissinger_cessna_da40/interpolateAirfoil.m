function [newX, newY] = interpolateAirfoil(X, Y, numPoints)
    % Calculate the cumulative arc length (chordwise distance)
    arcLength = [0; cumsum(sqrt(diff(X).^2 + diff(Y).^2))];
    
    % Normalize the arc length to range from 0 to 1
    arcLengthNormalized = arcLength / arcLength(end);
    
    % Generate equally spaced points for interpolation
    newArcLength = linspace(1e-4, 1, numPoints);
    
    % Interpolate both X and Y based on the normalized arc length
    newX = interp1(arcLengthNormalized, X, newArcLength, 'linear');
    newY = interp1(arcLengthNormalized, Y, newArcLength, 'linear');
end