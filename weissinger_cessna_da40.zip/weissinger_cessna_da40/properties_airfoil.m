function [cmb, cmb_x, cmb_v, newX_upper, newX_lower, newY_upper, newY_lower, cmb_pol] = properties_airfoil(airfoilData, k, numPoints)
    X = airfoilData{k}.coords(:,1); 
    Y = airfoilData{k}.coords(:,2);

    dx = diff(X);
    LEidx = find(dx >= 0, 1, 'first');
    if ~isempty(LEidx)
        X_upper = X(1:LEidx);
        X_lower = X(LEidx:end);
        Y_upper = Y(1:LEidx);
        Y_lower = Y(LEidx:end);
    end

    
    newX_upper = linspace(0, 1, numPoints);
    newY_upper = spline(X_upper, Y_upper, newX_upper);
    
    newX_lower = newX_upper;
    newY_lower = spline(X_lower, Y_lower, newX_lower);
    
    if ~isequal(newX_upper, newX_lower)
        error('Upper and lower X coordinates do not match. Check interpolation.');
    end
    
    camber = calculateAirfoilCamber(newX_upper, newY_upper, newX_lower, newY_lower);
    
    cmb_v = camber;
    [cmb, idx] = max(camber(:,2));  
    cmb_x = camber(idx, 1);    
    cmb_coeff = spline(cmb_v(:,1), cmb_v(:,2));
    cmb_pol = @(x) ppval(cmb_coeff, x);
end




