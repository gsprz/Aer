function airfoilData = loadAirfoil
    
    fileList = dir('*.dat'); 
    
    airfoilData = cell(length(fileList), 1);
    
    for i = 1:length(fileList)
        filename =fileList(i).name;
        
        fid = fopen(filename, 'r');

        airfoilName = fgetl(fid);
        
        airfoilCoords = fscanf(fid, '%f %f', [2, Inf])';  
        
        fclose(fid);
        
        airfoilData{i}.name = airfoilName;
        airfoilData{i}.coords = airfoilCoords;
    end
end 