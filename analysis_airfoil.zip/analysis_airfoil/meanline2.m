clc
clear all
close all

% PER PROFILI SIMMETRICI USARE NUMERO DISPARI DI PANNELLI

[airfoilData] = loadAirfoil;

airfoilDataTemp = cell(size(airfoilData));
for k = 1:size(airfoilData, 1) 
    % Extract individual airfoil data in the current iteration
    airfoilEntry = airfoilData{k};  
    alpha_th{k,1} = [];
    alpha_0{k,1} = [];
    num = linspace(1e3, 1e6, 30);
    for  j = 1:length(num)
    numPoints = num(j);
    m = [1e1 1e2 1e3 1e4 1e5 1e6];
        for i = 1:length(m)
            nm = m(i);
            % Compute properties for the current airfoil
            [cmb, cmb_x, cmb_v, newX_upper, newX_lower, newY_upper, newY_lower] = properties(airfoilData, k, numPoints, nm);
            
            % Store the computed properties in a temporary structure
            airfoilEntry.camber = cmb;         % Maximum camber
            airfoilEntry.camber_v = cmb_v;
            airfoilEntry.camber_x = cmb_x;
        
            % Assign the updated entry to the temporary array
            airfoilDataTemp{k} = airfoilEntry; 
        
            d_cmb_fun = diffFinite(nm, cmb_v);
            
            fun_den = @(s) sqrt((1/2)^2 - (s).^2);
            fun_peso_a0 = @(s) sqrt((1/2 + s)./(1/2 - s));
            
            % trasformo la derivata in una funzione di psi appartenente 
            % all'intervallo [0,1], tale che psi = s + L/2
            xx = linspace(0,1,numPoints);
            d_cmb_coeff = spline(d_cmb_fun(:,1), d_cmb_fun(:,2));
            d_cmb_pol = @(psi) ppval(d_cmb_coeff, psi);
            cmb_coeff = spline(cmb_v(:,1), cmb_v(:,2));
            cmb_pol = @(x) ppval(cmb_coeff, x);
            
            fun_int = @(s) 1/pi * d_cmb_pol(s + 1/2) ./ fun_den(s);
            fun_int_a0 = @(s) 2/pi * d_cmb_pol(s + 1/2) .* fun_peso_a0(s);
            
            % cambio variabile per risolvere l'integrale:
            % s = -L/2*cos(eta)
            
            % L = 1
            % s = -1/2*cos(eta)
            % ds = 1/2*sin(eta) deta
            
            fun_int_transformed = @(eta) 1/pi * d_cmb_pol(- 1/2.*cos(eta) + 1/2) .* ...
            ((1/2 .* sin(eta)) / fun_den(-1/2 .* cos(eta)));
            fun_int_transformed_a0 = @(eta) 2/pi * d_cmb_pol(- 1/2.*cos(eta) + 1/2) .* ...
             ((1/2 .* sin(eta)) .* fun_peso_a0(- 1/2 .* cos(eta)));
        
            alpha_0{k}(j,i) = rad2deg(simpcomp(0, pi - 1e-7, nm-1, fun_int_transformed_a0));
            alpha_th{k}(j,i) = rad2deg(simpcomp(0, pi, nm-1, fun_int_transformed));
        end
    end
    figure
    plot (xx, cmb_pol(xx))
    hold on
    plot(newX_upper, newY_upper, newX_lower, newY_lower)
    % plot(d_cmb_fun(:,1), d_cmb_fun(:,2));
    axis equal
    grid on
end

alpha_0_xfoil = -4.1523;
alpha_0_xfoil2 = -1.3091;
err1 = abs(abs(alpha_0{3}(end,end)) - abs(alpha_0_xfoil)) / abs(alpha_0_xfoil) * 100
err2 = abs(abs(alpha_0{1}(end,end)) - abs(alpha_0_xfoil2)) / abs(alpha_0_xfoil2) * 100


airfoilData = airfoilDataTemp;  


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% functions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [cmb, cmb_x, cmb_v, newX_upper, newX_lower, newY_upper, newY_lower, cmb_pol] = properties(airfoilData, k, numPoints, nm)
    X = airfoilData{k}.coords(:,1); 
    Y = airfoilData{k}.coords(:,2);
    dx = diff(X);
    LEidx = find(dx >= 0, 1, 'first');
    if ~isempty(LEidx)
        X_upper = X(1:LEidx);
        X_lower = X(LEidx:end);
        Y_upper = Y(1:LEidx);
        Y_lower = Y(LEidx:end);
    end

    newX_upper = linspace(0, 1, numPoints);
    newY_upper = spline(X_upper, Y_upper, newX_upper);
    
    newX_lower = newX_upper;
    newY_lower = spline(X_lower, Y_lower, newX_lower);
    
    if ~isequal(newX_upper, newX_lower)
        error('Upper and lower X coordinates do not match. Check interpolation.');
    end
    
    camber = calculateAirfoilCamber(newX_upper, newY_upper, newX_lower, newY_lower, nm);
    
    cmb_v = camber;
    [cmb, idx] = max(camber(:,2));  
    cmb_x = camber(idx, 1);    
    cmb_coeff = spline(cmb_v(:,1), cmb_v(:,2));
    cmb_pol = @(x) ppval(cmb_coeff, x);
end


function airfoilData = loadAirfoil
    
    fileList = dir('*.dat'); 
    
    airfoilData = cell(length(fileList), 1);
    
    for i = 1:length(fileList)
        filename =fileList(i).name;
        
        fid = fopen(filename, 'r');

        airfoilName = fgetl(fid);
        
        airfoilCoords = fscanf(fid, '%f %f', [2, Inf])';  
        
        fclose(fid);
        
        airfoilData{i}.name = airfoilName;
        airfoilData{i}.coords = airfoilCoords;
    end
end 


function [newX, newY] = interpolateAirfoil(X, Y, numPoints)
    % Calculate the cumulative arc length (chordwise distance)
    arcLength = [0; cumsum(sqrt(diff(X).^2 + diff(Y).^2))];
    
    % Normalize the arc length to range from 0 to 1
    arcLengthNormalized = arcLength / arcLength(end);
    
    % Generate equally spaced points for interpolation
    newArcLength = linspace(1e-4, 1, numPoints);
    
    % Interpolate both X and Y based on the normalized arc length
    newX = interp1(arcLengthNormalized, X, newArcLength, 'linear');
    newY = interp1(arcLengthNormalized, Y, newArcLength, 'linear');
end

function camber = calculateAirfoilCamber(X_upper, Y_upper, X_lower, Y_lower, nm)
    % Function to calculate the camber line of an airfoil
    % Inputs:
    %   X_upper, Y_upper: X and Y coordinates of the upper surface
    %   X_lower, Y_lower: X and Y coordinates of the lower surface
    % Output:
    %   camber: A matrix with two columns. 
    %           The first column is the X-coordinate of the camber line.
    %           The second column is the Y-coordinate of the camber line.

    % Ensure the surfaces have the same X-coordinates (if not, interpolate)
    if ~isequal(X_upper, X_lower)
        error('Upper and lower surfaces must have matching X-coordinates.');
    end
    XX = linspace(X_upper(1), X_upper(end), nm);
    YY_up = Y_upper(round(linspace(1, length(X_upper), nm)));
    YY_dw = Y_lower(round(linspace(1, length(X_upper), nm)));
    % Calculate the camber line as the midpoint between the upper and lower surfaces
    camberX = XX;  % X-coordinates of camber line (same as X_upper or X_lower)
    camberY = (YY_up + YY_dw) / 2;  % Y-coordinates of camber line (average of upper and lower)
    
    % Combine the X and Y coordinates into a single matrix
    camber = [camberX', camberY'];
end

function d_cmb_fun = diffFinite(numPoints, cmb_v)
    % Derivata con metodo delle differenze finite
    h = 1/numPoints; % passo costante preso come 1/numero totale di punti
    % differenze finite centrate per tutti i punti eccetto gli estremi:
    d_cmb_fun = zeros(length(cmb_v),2);
    for i = 2:length(cmb_v)-1
        d_cmb_fun(i,2) = (cmb_v(i+1,2) - cmb_v(i-1,2))/(2*h);
    end
    % differenze finite in avanti per il primo punto:
    d_cmb_fun(1,2) = (cmb_v(2,2) - cmb_v(1,2))/h;
    % differenze finite all'indietro per l'ultimo punto:
    d_cmb_fun(end,2) = (cmb_v(end,2) - cmb_v(end-1,2))/h;
    d_cmb_fun(:,1) = cmb_v(:,1);
end

function I = simpcomp(a,b,N,fun)
    h = (b-a)/N;

    x = a:(h/2):b;
    y = fun(x);

    I = (h/6) * ( ...
        y(1) + y(end) ...
        + 2 * sum(y(3:2:(end-2))) ...
        + 4 * sum(y(2:2:(end-1)))); 
    % prendo 3 e non 2 perchè 2 è il punto medio e devo saltarlo
end
